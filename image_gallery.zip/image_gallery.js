const images = [
    'images/taj.jpg',
    'images/redfort.jpg',
    'images/ranikivav.jpg',
    'images/Charminar.jpg'
  ];
  
  let currentIndex = 0;
  const galleryImage = document.getElementById("galleryImage");
  
  document.getElementById("nextBtn").addEventListener("click", () => {
    currentIndex = (currentIndex + 1) % images.length;
    galleryImage.src = images[currentIndex];
  });
  
  document.getElementById("prevBtn").addEventListener("click", () => {
    currentIndex = (currentIndex - 1 + images.length) % images.length;
    galleryImage.src = images[currentIndex];
  });
  