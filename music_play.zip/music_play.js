const audio = document.getElementById("audio-player");
const songInfo = document.getElementById("song-info");
const timeInfo = document.getElementById("time-info");
const toggleBtn = document.getElementById("toggleBtn");
const progressBar = document.getElementById("progressBar");
const playlistDiv = document.getElementById("playlist");

const playlist = ["music1.mp3", "music2.mp3"];
let currentSongIndex = 0;

function loadSong(index) {
  currentSongIndex = index;
  audio.src = playlist[index];
  songInfo.textContent = "Now Playing: " + playlist[index];
  progressBar.value = 0;
}

function togglePlay() {
  if (audio.paused) {
    audio.play();
    toggleBtn.textContent = "Pause";
  } else {
    audio.pause();
    toggleBtn.textContent = "Play";
  }
}

function stopAudio() {
  audio.pause();
  audio.currentTime = 0;
  toggleBtn.textContent = "Play";
}

function setVolume(value) {
  audio.volume = value;
}

function seekAudio(value) {
  audio.currentTime = value;
}

function formatTime(seconds) {
  
  if (isNaN(seconds)) return "00:00";
  const mins = Math.floor(seconds / 60);
  const secs = Math.floor(seconds % 60);
  return `${String(mins).padStart(2, "0")}:${String(secs).padStart(2, "0")}`;
}

audio.addEventListener("timeupdate", () => {
  progressBar.max = audio.duration;
  progressBar.value = audio.currentTime;
  let value1 =formatTime(audio.currentTime);
  let value2 = formatTime(audio.duration);
  timeInfo.textContent =` ${value1 }\ ${value2}`;
 
});

audio.addEventListener("ended", () => {
  currentSongIndex = (currentSongIndex + 1) % playlist.length;
  loadSong(currentSongIndex);
  audio.play();
  toggleBtn.textContent = "Pause";
});

function renderPlaylist() {
  playlist.forEach((song, index) => {
    const btn = document.createElement("button");
    btn.textContent = song;
    btn.onclick = () => {
      loadSong(index);
      audio.play();
      toggleBtn.textContent = "Pause";
    };
    playlistDiv.appendChild(btn);
  });
}

loadSong(currentSongIndex);
renderPlaylist();
